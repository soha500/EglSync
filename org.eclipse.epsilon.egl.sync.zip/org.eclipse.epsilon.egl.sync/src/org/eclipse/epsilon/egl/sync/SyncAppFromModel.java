package org.eclipse.epsilon.egl.sync;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.eclipse.epsilon.emc.emf.EmfModel;
import org.eclipse.epsilon.eol.exceptions.EolRuntimeException;
import org.eclipse.epsilon.eol.exceptions.models.EolModelLoadingException;
import org.eclipse.epsilon.eol.execute.introspection.IPropertyGetter;
import org.eclipse.epsilon.eol.execute.introspection.IPropertySetter;
import org.eclipse.epsilon.eol.models.IModel;

public class SyncAppFromModel {
	//old one 
	private static final String FOLDER_PATH ="/SimpleExample/All-Generated-Files";
	//new one
//	private static final String FOLDER_PATH ="/New-Generated-Files";


	public static void main(String[] args) throws EolModelLoadingException, IOException {
		//List<Synchronization> listObjects = new ArrayList<Synchronization>();
		
		EmfModel model = new EmfModel();
		model.setName("M");
		model.setMetamodelFile(new File("Statemachine.ecore").getAbsolutePath());
		//old one
		model.setModelFile(new File("SimpleExample/models/Statemachine.model").getAbsolutePath());

		// new one
//		model.setModelFile(new File("Statemachine.model").getAbsolutePath());
		

		model.setReadOnLoad(true);
		model.setStoredOnDisposal(true);

		try {
			model.load();
		} catch (EolModelLoadingException e2) {
			e2.printStackTrace();
		}
		
		FolderSync syncReader = new FolderSync();
		syncReader.getSynchronization(FOLDER_PATH, model);


	}
}