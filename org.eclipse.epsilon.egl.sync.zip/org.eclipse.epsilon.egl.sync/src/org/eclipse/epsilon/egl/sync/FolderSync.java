package org.eclipse.epsilon.egl.sync;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.eclipse.epsilon.eol.exceptions.EolRuntimeException;
import org.eclipse.epsilon.eol.execute.introspection.IPropertyGetter;
import org.eclipse.epsilon.eol.execute.introspection.IPropertySetter;
import org.eclipse.epsilon.eol.models.IModel;

public class FolderSync {

	public List<Synchronization> getAllTheSyncsRegionsOfTheFolder(String folder) {

		Path folderPath = Paths.get(folder);

		// call all list of the files in the folder
		List<String> fileNames = new ArrayList<>();

		try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(folderPath)) {
			for (Path path : directoryStream) {
				fileNames.add(path.toString());
			}
		} catch (IOException ex) {
			System.err.println("Error reading files");
			ex.printStackTrace();
		}

		// create data structure for all files's names and contents in the folder
		Map<String, List<String>> namesAndContents = new TreeMap<String, List<String>>();

		List<Synchronization> allTheSyncRegionsInTheFolder = new ArrayList<Synchronization>();

		for (String file : fileNames) {

			try {
				// put the generated file's name and its content into the data structure
				List<String> content = Files.readAllLines(folderPath.resolve(file));
				namesAndContents.put(file, content);

				FileSync fileSync = new FileSync(file);
				List<Synchronization> syncRegionsOfThisFile = fileSync.getAllTheSyncRegionsOfTheFile();
				allTheSyncRegionsInTheFolder.addAll(syncRegionsOfThisFile);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return allTheSyncRegionsInTheFolder;

	}

	public void updateTheModel(IModel model, List<Synchronization> allTheSyncsRegionOfTheFolder) {

//		for (Synchronization sync : allTheSyncsRegionOfTheFolder) {
//			
//			IPropertyGetter propertyGetter = model.getPropertyGetter();
//			Object modelElement = model.getElementById(sync.getId());
//			try {
//				System.out.println(propertyGetter.invoke(modelElement, sync.getAttribute()));
//				//System.out.println();
//
//			} catch (EolRuntimeException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}

		checkSyncs(model, allTheSyncsRegionOfTheFolder);

	}

	public void getSynchronization(String folder, IModel model) {

		List<Synchronization> allTheSyncRegionsInTheFolder = new ArrayList<Synchronization>();

		allTheSyncRegionsInTheFolder = getAllTheSyncsRegionsOfTheFolder(folder);

		for (Synchronization sync : allTheSyncRegionsInTheFolder) {
//			System.out.println(sync.getId());
//			System.out.println(sync.getAttribute());
//			System.out.println(sync.getContent());
		}

		updateTheModel(model, allTheSyncRegionsInTheFolder);
	}


public void checkSyncs(IModel model, List<Synchronization> allTheSyncsRegionOfTheFolder) {
	
	//create a data structure
	//Map<String, ArrayList<String>> allValuesInSyncRegion = new HashMap<String, ArrayList<String>>();
	Map<String, Set<String>> allValuesInSyncRegion = new HashMap<String, Set<String>>();

	for (Synchronization sync : allTheSyncsRegionOfTheFolder) {

		try {
			IPropertyGetter propertyGetter = model.getPropertyGetter();
			
			Object modelElement = model.getElementById(sync.getId());
			
			String valueOfAttributeInTheModel = (String) propertyGetter.invoke(modelElement, sync.getAttribute());

			String valueOfAttributeInSyncRegion = (String) sync.getContent();
			
			
			// new array without duplicated values
			Set<String> valuesInSyncRegionWithoutDuplactie = new HashSet<>();
			
			// Concatenation Id and attribute in model to have one key 
			String key = sync.getId() + "." + sync.getAttribute();


			//for (String synchronization : listOfAllValluesInSyncRegion) {	
			
			valuesInSyncRegionWithoutDuplactie.add(valueOfAttributeInSyncRegion);

			if (allValuesInSyncRegion.containsKey(key))
				allValuesInSyncRegion.get(key).add(valueOfAttributeInSyncRegion);
			else
				allValuesInSyncRegion.put(key, valuesInSyncRegionWithoutDuplactie);

			
			if (allValuesInSyncRegion.get(key).size() == 1) {
				ArrayList<String> values = new ArrayList(allValuesInSyncRegion.get(key));
				if (valueOfAttributeInTheModel.equals(values.get(0))) {
					

					System.out.println("size 1 same "+ valueOfAttributeInSyncRegion);

				} else {
					System.out.println("size 1 differnt " + valueOfAttributeInSyncRegion);

					Object modelElement1 = model.getElementById(sync.getId());
					IPropertySetter propertySetter = model.getPropertySetter();
					propertySetter.setObject(modelElement1);
					propertySetter.setProperty(sync.getAttribute());
					try {
						propertySetter.invoke(values.get(0));
					} catch (EolRuntimeException e) {
						e.printStackTrace();
					}
					model.store();
					return;
				}

			} else if (allValuesInSyncRegion.get(key).size() == 2) {
				ArrayList<String> values = new ArrayList(allValuesInSyncRegion.get(key));
				
				if (valueOfAttributeInTheModel.equals(values.get(0))) {
					Object modelElement1 = model.getElementById(sync.getId());

					IPropertySetter propertySetter = model.getPropertySetter();
					propertySetter.setObject(modelElement1);
					propertySetter.setProperty(sync.getAttribute());
					try {
						propertySetter.invoke(values.get(1));
					} catch (EolRuntimeException e) {
						e.printStackTrace();
					}
					model.store();
					
				} else if (valueOfAttributeInTheModel.equals(values.get(1))) {
					Object modelElement1 = model.getElementById(sync.getId());

					IPropertySetter propertySetter = model.getPropertySetter();
					propertySetter.setObject(modelElement1);
					propertySetter.setProperty(sync.getAttribute());
					try {
						propertySetter.invoke(values.get(0));
					} catch (EolRuntimeException e) {
						e.printStackTrace();
					}
					model.store();
					
				} else {
					System.out.println("two different values ");

				}
				
			} else {
				System.out.println("more than two values");
			}
			
		} catch (EolRuntimeException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

}
}

